"""Attendance services and analytics."""
