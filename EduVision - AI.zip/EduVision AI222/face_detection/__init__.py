"""OpenCV face detection helpers."""
