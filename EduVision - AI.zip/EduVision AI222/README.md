# AI College Attendance and Management System

Python prototype for a college attendance platform with:

- Role-based login for Admin, HOD, Teacher, and Student
- SQLite master data and attendance storage
- Student ERP validation and face enrollment
- Face embeddings using `face_recognition`
- Image, video, and webcam-based attendance capture
- Subject-wise attendance analytics and risk alerts
- Prototype pass/fail prediction using attendance patterns

## Run

```bash
pip install -r requirements.txt
python main.py
```

Default admin credentials:

- Username: `admin`
- Password: `Admin@DVSIET2026!`

## Project Notes

- Student signup uses ERP validation and stores the student login as the ERP ID.
- The local package for recognition utilities is named `face_services/` to avoid shadowing the external `face_recognition` library.
- Live camera attendance is available with:

```bash
python main.py --camera-attendance --assignment-id 1 --teacher-id 1
```
