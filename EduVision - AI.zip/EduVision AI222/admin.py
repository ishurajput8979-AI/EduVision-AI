"""Compatibility wrapper for admin routes."""

from routes.admin import admin_bp

__all__ = ["admin_bp"]
